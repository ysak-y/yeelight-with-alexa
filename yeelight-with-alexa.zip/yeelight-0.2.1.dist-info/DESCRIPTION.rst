A Python library for controlling YeeLight RGB bulbs through WiFi.


